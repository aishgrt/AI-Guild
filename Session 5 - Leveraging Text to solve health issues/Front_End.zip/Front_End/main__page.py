#import proper libraries
import pandas as pd
import os
import numpy as np
import random
import pickle as pkl
import nltk
import string
from nltk.corpus import stopwords
from autocorrect import Speller
from nltk import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from data_preprocessing import Text_Preprocessing
from data_preprocessing import lemma
from data_preprocessing import punct_list
from data_preprocessing import stop_words
from data_preprocessing import check
import streamlit as st


#receive text input from the user
st.set_option('deprecation.showPyplotGlobalUse', False)
text=st.text_input("Put your medical input here.","Device crack")
#instantiate text cleaning pipeline
tp=Text_Preprocessing(punct_list,stop_words,lemma)

#execute the text cleaning pipeline on the input
finalized_text=[]
no_punct=tp.punctuation(text)
no_stop=tp.punctuation(no_punct)
spelled=tp.spelling(no_stop)
lemmatized_text=tp.lemmatize(spelled)
finalized_text.append(lemmatized_text)
print(finalized_text)


#import the models
rf=open('../Model_Creation/tfidf_model.pkl','rb')
tfidf=pkl.load(rf)
rf.close()


#vectorize the given input
vectorized_text=tfidf.transform(finalized_text)
dense_matrix=vectorized_text.todense()
features=tfidf.get_feature_names()
text_entries=pd.DataFrame(dense_matrix)
text_entries.columns=features


#import the models
rf=open('../Model_Creation/logistic_regression.pkl','rb')
lr_fit=pkl.load(rf)
rf.close()


rf=open('../Model_Creation/coef_matrix.pkl','rb')
coef_mat=pkl.load(rf)
rf.close()

#get a proper prediction
prediction=lr_fit.predict(text_entries)
if prediction ==0:
    st.write('This device should not be harmful.')
else:
    st.write('This device is potentially harmful')

#plot the weights the model assigned to each word
#display on the dashboard
list_frames=[]
for i in finalized_text[0].split(' '):
    extracted=coef_mat[coef_mat.index==i.lower()]
    list_frames.append(extracted)
pd.concat(list_frames).plot(kind='bar')
st.pyplot()
