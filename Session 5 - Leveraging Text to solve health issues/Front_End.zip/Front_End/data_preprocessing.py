
import pandas as pd
import os
import numpy as np
import random
import pickle as pkl
import nltk
import string
from nltk.corpus import stopwords
from autocorrect import Speller
from nltk import WordNetLemmatizer

lemma=WordNetLemmatizer()
nltk.download("punkt")
nltk.download('stopwords')
punct_list=string.punctuation
stop_words=stopwords.words('english')
check=Speller(lang='en')
punct_list=punct_list+'¿1234567890'

class Text_Preprocessing:

    def __init__(self,punct_list,stop_word_list,lemmatizer):
        self.punct_list=punct_list
        self.stop_word_list=stop_word_list
        self.lemma=lemma
        self.check=check

    def punctuation(self,text):
        no_punct=[i.translate(str.maketrans(' ',' ',self.punct_list)) for i in text.lower().split(' ')]
        return ' '.join(no_punct)

    def stop_words(self,text):
        no_stop=[i for i in text.lower().split(' ') if i not in self.stop_word_list]
        return ' '.join(no_stop)

    def get_word_set(self,full_text):
        word_list=[]
        for i in full_text:
            for j in i.split(' '):
                word_list.append(j)
        return set(word_list)

    def create_spelling_dict(self,word_list):
        spelling_dict={}
        p=0
        for i in finalized_word_list:
            spelling_dict[i]=tp.check(i)
            if p%1000==0:
                print(p)
            p+=1
        f=open('spelling_dict.pkl','wb')
        pkl.dump(spelling_dict,f)
        f.close()
        return spelling_dict


    def spelling(self,i):
        rf=open('../Model_Creation/spelling_dict.pkl','rb')
        spelling_dict_t=pkl.load(rf)
        rf.close()

        properly_spelled=[]
        for j in i.split(' '):
            if j in spelling_dict_t.keys():
                properly_spelled.append(spelling_dict_t[j])
            else:
                properly_spelled.append(j)
        return ' '.join(properly_spelled)

    def lemmatize(self,text):
        lemmatized_text=[self.lemma.lemmatize(i) for i in text.lower().split(' ')]
        return ' '.join(lemmatized_text)
